# Enterprise_App_Development Lab 1
To visualise the website just run index.html
The original bootstrap is this: https://themewagon.com/themes/free-bootstrap-5-html-5-business-website-template-mirko/
 
